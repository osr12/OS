OSR EV Website
Admin:
 Username: OSR
 Password: Osr@9998
Admin Panel: https://osrr.store/OSR9998/admin.php
